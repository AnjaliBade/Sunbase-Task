const apiUrl = 'http://localhost:8080/api/customers';
const authUrl = 'http://localhost:8080/api/authenticate';

document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    } else {
        loadCustomers();
        document.getElementById('customerForm').addEventListener('submit', handleCustomerSubmit);
        document.getElementById('syncButton').addEventListener('click', handleSync);
    }
});

function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    fetch(authUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
        .then(response => response.json())
        .then(data => {
            localStorage.setItem('token', data.token);
            window.location.href = 'index.html';
        })
        .catch(error => console.error('Error:', error));
}

function loadCustomers() {
    const token = localStorage.getItem('token');
    fetch(apiUrl, {
        method: 'GET',
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#customerTable tbody');
            tbody.innerHTML = '';
            data.forEach(customer => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.id}</td>
                    <td>${customer.firstName}</td>
                    <td>${customer.lastName}</td>
                    <td>${customer.street}</td>
                    <td>${customer.address}</td>
                    <td>${customer.city}</td>
                    <td>${customer.state}</td>
                    <td>${customer.email}</td>
                    <td>${customer.phone}</td>
                    <td>
                        <button onclick="editCustomer(${customer.id})">Edit</button>
                        <button onclick="deleteCustomer(${customer.id})">Delete</button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));
}

function handleCustomerSubmit(event) {
    event.preventDefault();
    const token = localStorage.getItem('token');
    const id = document.getElementById('customerId').value;
    const customer = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        street: document.getElementById('street').value,
        address: document.getElementById('address').value,
        city: document.getElementById('city').value,
        state: document.getElementById('state').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value
    };

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${apiUrl}/${id}` : apiUrl;

    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify(customer)
    })
        .then(() => {
            loadCustomers();
            document.getElementById('customerForm').reset();
        })
        .catch(error => console.error('Error:', error));
}

function editCustomer(id) {
    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/${id}`, {
        method: 'GET',
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
        .then(response => response.json())
        .then(customer => {
            document.getElementById('customerId').value = customer.id;
            document.getElementById('firstName').value = customer.firstName;
            document.getElementById('lastName').value = customer.lastName;
            document.getElementById('street').value = customer.street;
            document.getElementById('address').value = customer.address;
            document.getElementById('city').value = customer.city;
            document.getElementById('state').value = customer.state;
            document.getElementById('email').value = customer.email;
            document.getElementById('phone').value = customer.phone;
        })
        .catch(error => console.error('Error:', error));
}

function deleteCustomer(id) {
    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/${id}`, {
        method: 'DELETE',
        headers: {
            'Authorization': 'Bearer ' + token
        }
    })
        .then(() => loadCustomers())
        .catch(error => console.error('Error:', error));
}

function handleSync() {
    const token = localStorage.getItem('token');
    fetch('https://qa.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({
            login_id: 'test@sunbasedata.com',
            password: 'Test@123'
        })
    })
        .then(response => response.json())
        .then(data => {
            data.forEach(customer => {
                fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    },
                    body: JSON.stringify(customer)
                });
            });
            loadCustomers();
        })
        .catch(error => console.error('Error:', error));
}
